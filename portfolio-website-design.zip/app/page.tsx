import { HeroSection } from "@/components/hero-section"
import { TechStackBar } from "@/components/tech-stack-bar"
import { ProjectsSection } from "@/components/projects-section"
import { CertificationsSection } from "@/components/certifications-section"
import { SkillsSection } from "@/components/skills-section"
import { ContactSection } from "@/components/contact-section"
import { Footer } from "@/components/footer"
import { AnimatedCursor } from "@/components/animated-cursor"
import { FloatingSymbols } from "@/components/floating-symbols"

export default function Home() {
  return (
    <main className="relative w-full overflow-x-hidden bg-black">
      <AnimatedCursor />
      <FloatingSymbols />

      <HeroSection />
      <TechStackBar />
      <ProjectsSection />
      <CertificationsSection />
      <SkillsSection />
      <ContactSection />
      <Footer />
    </main>
  )
}
