"use client"

import { useEffect, useRef } from "react"

export function AnimatedCursor() {
  const cursorRef = useRef<HTMLDivElement>(null)
  const glowRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!cursorRef.current || !glowRef.current) return

      const x = e.clientX
      const y = e.clientY

      cursorRef.current.style.left = x + "px"
      cursorRef.current.style.top = y + "px"
      glowRef.current.style.left = x + "px"
      glowRef.current.style.top = y + "px"
    }

    window.addEventListener("mousemove", handleMouseMove)
    return () => window.removeEventListener("mousemove", handleMouseMove)
  }, [])

  return (
    <>
      <div
        ref={glowRef}
        className="fixed pointer-events-none w-32 h-32 rounded-full z-50"
        style={{
          background: "radial-gradient(circle, rgba(147, 51, 234, 0.2) 0%, transparent 70%)",
          transform: "translate(-50%, -50%)",
          mixBlendMode: "screen",
        }}
      />
      <div
        ref={cursorRef}
        className="fixed pointer-events-none w-2 h-2 rounded-full z-50"
        style={{
          background: "linear-gradient(135deg, #9333EA, #EC4899)",
          transform: "translate(-50%, -50%)",
          boxShadow: "0 0 10px rgba(147, 51, 234, 0.8), 0 0 20px rgba(236, 72, 153, 0.5)",
        }}
      />
    </>
  )
}
