"use client"

import { Mail, Calendar, Send, Terminal, Phone } from "lucide-react"

export function ContactSection() {
  return (
    <section className="relative py-20 px-4 md:px-8 lg:px-16">
      <div className="max-w-4xl mx-auto">
        <div className="glass rounded-2xl p-8 md:p-16 neon-glow text-center">
          {/* Icon */}
          <div className="inline-flex p-4 rounded-full bg-gradient-to-br from-purple-600 to-pink-600 mb-6">
            <Terminal size={32} className="text-white" />
          </div>

          {/* Content */}
          <h2 className="text-4xl md:text-5xl font-bold gradient-text mb-4">Let's Collaborate</h2>
          <p className="text-gray-400 text-lg mb-2">Open to internships, projects, and innovative ideas</p>
          <p className="text-gray-500 text-sm font-mono mb-8">
            // Get in touch and let's create something amazing together
          </p>

          {/* Contact Info */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
            <a
              href="mailto:akshaykairam001@gmail.com"
              className="glass rounded-lg p-4 hover-scale glass-hover flex items-center justify-center gap-3"
            >
              <Mail size={20} className="text-purple-400" />
              <span>akshaykairam001@gmail.com</span>
            </a>
            <a
              href="tel:+916304892087"
              className="glass rounded-lg p-4 hover-scale glass-hover flex items-center justify-center gap-3"
            >
              <Phone size={20} className="text-pink-400" />
              <span>+91 6304892087</span>
            </a>
          </div>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="glass rounded-lg px-8 py-3 font-medium flex items-center justify-center gap-2 hover-scale glass-hover bg-gradient-to-r from-cyan-600/20 to-purple-600/20 hover:from-cyan-600/30 hover:to-purple-600/30 border border-cyan-500/30">
              <Send size={20} />
              Send Message
            </button>
            <button className="rounded-lg px-8 py-3 font-medium flex items-center justify-center gap-2 border-2 border-purple-500 hover:bg-purple-500/10 hover-scale transition-all">
              <Calendar size={20} />
              Schedule Call
            </button>
          </div>
        </div>
      </div>
    </section>
  )
}
