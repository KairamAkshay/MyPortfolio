"use client"

import { Award } from "lucide-react"

const certifications = [
  {
    title: "AWS Academy Graduate - Cloud Developing",
    issuer: "Amazon Web Services (AWS)",
    date: "Nov 2025 - Aug 2030",
    credentialId: "Jf6RsowG",
    skills: ["Cloud Computing", "Amazon Web Services (AWS)"],
    logo: "☁️",
  },
  {
    title: "Microsoft Certified: Azure AI Fundamentals",
    issuer: "Microsoft",
    date: "Aug 2025 - Aug 2030",
    credentialId: "FkJC-XMpE",
    skills: ["Artificial Intelligence (AI)", "Microsoft Azure"],
    logo: "🔷",
  },
  {
    title: "AWS Academy Graduate - Cloud Foundations",
    issuer: "Amazon Web Services (AWS)",
    date: "Mar 2025 - Mar 2030",
    credentialId: "JGTpAiHP",
    skills: ["Cloud Computing", "Amazon Web Services (AWS)"],
    logo: "☁️",
  },
  {
    title: "Tata Group - Data Visualisation",
    issuer: "Forage",
    date: "Dec 2024",
    credentialId: "QxWwtS6NFt3uwz6vF",
    skills: ["Data Visualization"],
    logo: "📊",
  },
  {
    title: "Juniper Networks Certified Associate - Junos (JNCIA-Junos)",
    issuer: "AICTE",
    date: "Oct 2024 - Dec 2024",
    credentialId: "c5b0545ddce4b6b3c070bcffe4356da8",
    skills: ["Artificial Intelligence (AI)"],
    logo: "🌐",
  },
  {
    title: "AIML Virtual Internship",
    issuer: "Google for Developers",
    date: "Jul 2024 - Sep 2024",
    credentialId: "65388a03a833b1eb34517bf32297edca",
    skills: ["Artificial Intelligence (AI)", "Machine Learning"],
    logo: "🤖",
  },
]

export function CertificationsSection() {
  return (
    <section className="relative w-full px-4 py-20 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-7xl">
        {/* Section Header */}
        <div className="mb-16 text-center">
          <div className="mb-4 flex items-center justify-center gap-2">
            <span className="text-cyan-400">{"<"}</span>
            <h2 className="font-mono text-4xl font-bold text-white lg:text-5xl">Certifications</h2>
            <span className="text-cyan-400">{"/>"}</span>
          </div>
          <p className="mx-auto max-w-2xl font-mono text-lg text-gray-400">// Professional credentials and training</p>
        </div>

        {/* Certifications Grid */}
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {certifications.map((cert, index) => (
            <div
              key={index}
              className="group relative overflow-hidden rounded-2xl border border-purple-500/20 bg-black/40 p-6 backdrop-blur-xl transition-all duration-300 hover:border-purple-500/50 hover:bg-black/60"
            >
              {/* Gradient overlay on hover */}
              <div className="absolute inset-0 bg-gradient-to-br from-purple-500/5 via-transparent to-cyan-500/5 opacity-0 transition-opacity duration-300 group-hover:opacity-100" />

              <div className="relative z-10">
                {/* Logo and Title */}
                <div className="mb-4 flex items-start gap-3">
                  <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-purple-500/20 to-cyan-500/20 text-2xl">
                    {cert.logo}
                  </div>
                  <div className="flex-1">
                    <h3 className="mb-1 font-mono text-lg font-semibold leading-tight text-white">{cert.title}</h3>
                    <p className="font-mono text-sm text-purple-400">{cert.issuer}</p>
                  </div>
                </div>

                {/* Date */}
                <div className="mb-3 flex items-center gap-2 font-mono text-sm text-gray-400">
                  <Award className="h-4 w-4" />
                  <span>{cert.date}</span>
                </div>

                {/* Credential ID */}
                <div className="mb-4 rounded-lg bg-black/50 p-3">
                  <p className="font-mono text-xs text-gray-500">Credential ID</p>
                  <p className="font-mono text-sm text-cyan-400">{cert.credentialId}</p>
                </div>

                {/* Skills */}
                <div className="flex flex-wrap gap-2">
                  {cert.skills.map((skill, idx) => (
                    <span
                      key={idx}
                      className="rounded-full bg-gradient-to-r from-purple-500/20 to-pink-500/20 px-3 py-1 font-mono text-xs text-gray-300"
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </div>

              {/* Corner accent */}
              <div className="absolute right-0 top-0 h-20 w-20 bg-gradient-to-bl from-cyan-500/10 to-transparent" />
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
