"use client"

const symbols = ["</>", "{}", "[]", "λ", "∑", "∏", "∫", "→", "←", "↓", "↑"]

export function FloatingSymbols() {
  return (
    <>
      {symbols.map((symbol, i) => (
        <div
          key={i}
          className="floating-symbol"
          style={{
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
            fontSize: `${Math.random() * 20 + 16}px`,
            color: ["#9333EA", "#EC4899", "#06B6D4"][Math.floor(Math.random() * 3)],
            animationDelay: `${i * 0.5}s`,
          }}
        >
          {symbol}
        </div>
      ))}
    </>
  )
}
