"use client"

import { useEffect, useRef } from "react"

const skillCategories = [
  {
    title: "Programming Languages",
    skills: [
      { name: "Python", icon: "🐍", percentage: 95 },
      { name: "JavaScript", icon: "⚛️", percentage: 90 },
      { name: "TypeScript", icon: "📘", percentage: 88 },
      { name: "Java", icon: "☕", percentage: 85 },
      { name: "C++", icon: "⚡", percentage: 80 },
      { name: "SQL", icon: "📊", percentage: 92 },
    ],
  },
  {
    title: "Technologies & Frameworks",
    skills: [
      { name: "React & Next.js", icon: "⚛️", percentage: 93 },
      { name: "Node.js", icon: "🟢", percentage: 88 },
      { name: "TensorFlow", icon: "🧠", percentage: 85 },
      { name: "Docker & K8s", icon: "🐳", percentage: 82 },
      { name: "AWS & Azure", icon: "☁️", percentage: 80 },
      { name: "MongoDB & PostgreSQL", icon: "📦", percentage: 87 },
    ],
  },
]

function SkillBar({ name, icon, percentage }: { name: string; icon: string; percentage: number }) {
  const progressRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && progressRef.current) {
          progressRef.current.style.setProperty("--percentage", `${percentage}%`)
        }
      },
      { threshold: 0.5 },
    )

    if (progressRef.current) {
      observer.observe(progressRef.current)
    }

    return () => observer.disconnect()
  }, [percentage])

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <span className="flex items-center gap-2 text-sm font-medium">
          <span>{icon}</span>
          {name}
        </span>
        <span className="text-sm text-purple-400 font-mono">{percentage}%</span>
      </div>
      <div className="h-2 bg-gray-800 rounded-full overflow-hidden">
        <div ref={progressRef} className="progress-bar h-full" style={{ width: "0%" }} />
      </div>
    </div>
  )
}

export function SkillsSection() {
  return (
    <section className="relative py-20 px-4 md:px-8 lg:px-16">
      <div className="absolute inset-0 bg-gradient-to-b from-purple-500/5 via-transparent to-pink-500/5" />

      <div className="relative z-10 max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="mb-16">
          <span className="text-sm text-gray-400 font-mono">// Technical Skills</span>
          <h2 className="text-4xl md:text-5xl font-bold gradient-text mt-2 mb-4">Expertise & Proficiency</h2>
        </div>

        {/* Skills Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {skillCategories.map((category, i) => (
            <div key={i} className="space-y-8">
              <h3 className="text-2xl font-bold text-white">{category.title}</h3>

              <div className="space-y-6">
                {category.skills.map((skill, j) => (
                  <SkillBar key={j} {...skill} />
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
