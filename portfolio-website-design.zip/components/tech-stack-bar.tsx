"use client"

import { useEffect, useRef } from "react"

const technologies = [
  "React",
  "Node.js",
  "Python",
  "TensorFlow",
  "Docker",
  "Kubernetes",
  "MongoDB",
  "PostgreSQL",
  "Redis",
  "AWS",
  "Azure",
  "Git",
  "TypeScript",
  "Next.js",
  "GraphQL",
  "FastAPI",
  "PyTorch",
]

export function TechStackBar() {
  const scrollRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const scroll = scrollRef.current
    if (!scroll) return

    const animate = () => {
      if (scroll.scrollLeft >= scroll.scrollWidth / 2) {
        scroll.scrollLeft = 0
      } else {
        scroll.scrollLeft += 1
      }
    }

    const interval = setInterval(animate, 30)
    return () => clearInterval(interval)
  }, [])

  return (
    <section className="relative py-12 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-r from-purple-500/10 via-pink-500/5 to-cyan-500/10" />

      <div className="relative z-10">
        <h3 className="text-center text-sm text-gray-400 mb-8 font-mono">// Tech Stack & Tools</h3>

        <div ref={scrollRef} className="flex gap-4 overflow-x-hidden px-8 pb-4" style={{ scrollBehavior: "smooth" }}>
          {[...technologies, ...technologies].map((tech, i) => (
            <div key={i} className="glass rounded-full px-6 py-3 whitespace-nowrap hover-scale glass-hover">
              <span className="text-sm font-medium gradient-text">{tech}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
