"use client"

import { ArrowRight, Brain, Music, Zap } from "lucide-react"

const projects = [
  {
    title: "Adaptive Crypto Trading Bot",
    subtitle: "Solana + Sentiment Analysis",
    tech: ["Reinforcement Learning", "NLP", "Blockchain", "Python"],
    icon: Zap,
    gradient: "from-yellow-600 to-orange-600",
    description:
      "AI-driven crypto trading system with real-time sentiment analysis and dynamic strategy adjustment on Solana blockchain.",
    date: "Aug 2025 - Nov 2025",
  },
  {
    title: "Music Analytics Project",
    subtitle: "Listener Growth Prediction",
    tech: ["ML Models", "Data Engineering", "Statistics", "Python"],
    icon: Music,
    gradient: "from-purple-600 to-pink-600",
    description:
      "Analyzed 15,000 music tracks using SVM, KNN, Random Forest to forecast listener growth and predict music trends.",
    date: "Oct 2024 - Dec 2024",
  },
  {
    title: "Smart India Hackathon",
    subtitle: "Team Participant",
    tech: ["Problem Solving", "Ideation", "Prototyping", "Teamwork"],
    icon: Brain,
    gradient: "from-cyan-600 to-blue-600",
    description:
      "Contributed to solution design and prototype planning in college-level internal rounds with focus on real-world problem solving.",
    date: "2024",
  },
]

export function ProjectsSection() {
  return (
    <section id="projects-section" className="relative py-20 px-4 md:px-8 lg:px-16">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="mb-16">
          <span className="text-sm text-gray-400 font-mono">// Featured Projects</span>
          <h2 className="text-4xl md:text-5xl font-bold gradient-text mt-2 mb-4">My Work & Creations</h2>
          <p className="text-gray-400 max-w-2xl">
            Real projects showcasing my expertise in AI/ML, data engineering, and blockchain automation.
          </p>
        </div>

        {/* Projects Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {projects.map((project, i) => {
            const Icon = project.icon
            return (
              <div
                key={i}
                className="group glass rounded-xl p-6 hover-scale glass-hover overflow-hidden relative h-full flex flex-col"
              >
                {/* Terminal Dots */}
                <div className="flex gap-2 mb-6">
                  <div className="w-3 h-3 rounded-full bg-red-500" />
                  <div className="w-3 h-3 rounded-full bg-yellow-500" />
                  <div className="w-3 h-3 rounded-full bg-green-500" />
                </div>

                {/* Icon */}
                <div
                  className={`inline-flex p-3 rounded-lg bg-gradient-to-br ${project.gradient} w-fit mb-4 opacity-80 group-hover:opacity-100 transition-opacity`}
                >
                  <Icon size={24} className="text-white" />
                </div>

                {/* Title & Date */}
                <h3 className="text-xl font-bold text-white mb-1 group-hover:gradient-text transition-all">
                  {project.title}
                </h3>
                <p className="text-sm text-purple-400 font-medium mb-2">{project.subtitle}</p>
                <p className="text-xs text-gray-500 mb-3 font-mono">{project.date}</p>
                <p className="text-sm text-gray-400 mb-4 flex-grow">{project.description}</p>

                {/* Tech Stack */}
                <div className="flex flex-wrap gap-2 mb-6">
                  {project.tech.map((tech, j) => (
                    <span
                      key={j}
                      className="text-xs px-3 py-1 rounded-full bg-purple-500/10 text-purple-300 border border-purple-500/20"
                    >
                      {tech}
                    </span>
                  ))}
                </div>

                {/* CTA Button */}
                <button className="flex items-center gap-2 text-sm font-medium text-purple-400 group-hover:text-pink-400 transition-colors">
                  View Details
                  <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </button>

                {/* Gradient Background */}
                <div
                  className={`absolute inset-0 bg-gradient-to-br ${project.gradient} opacity-0 group-hover:opacity-5 transition-opacity rounded-xl -z-10`}
                />
              </div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
