"use client"

import { useEffect, useState } from "react"
import { Linkedin, Github, Download, ArrowRight } from "lucide-react"

export function HeroSection() {
  const [displayText, setDisplayText] = useState("")
  const fullText = "const developer = new CSE_Student();"

  useEffect(() => {
    let index = 0
    const interval = setInterval(() => {
      if (index <= fullText.length) {
        setDisplayText(fullText.slice(0, index))
        index++
      } else {
        clearInterval(interval)
      }
    }, 50)

    return () => clearInterval(interval)
  }, [])

  const handleDownloadResume = () => {
    const link = document.createElement("a")
    link.href = "/resume/Kairam_Akshay_Resume.pdf"
    link.download = "Kairam_Akshay_Resume.pdf"
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }

  const scrollToProjects = () => {
    const projectsSection = document.getElementById("projects-section")
    if (projectsSection) {
      projectsSection.scrollIntoView({ behavior: "smooth" })
    }
  }

  return (
    <section className="relative min-h-screen flex items-center justify-center px-4 md:px-8 lg:px-16 py-20 overflow-hidden">
      <div className="max-w-7xl w-full grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
        {/* Left Content */}
        <div className="z-10 space-y-8">
          {/* Terminal Window */}
          <div className="glass rounded-lg overflow-hidden neon-glow">
            <div className="bg-black/50 px-4 py-3 border-b border-purple-500/20 flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-red-500" />
              <div className="w-3 h-3 rounded-full bg-yellow-500" />
              <div className="w-3 h-3 rounded-full bg-green-500" />
              <span className="text-gray-400 text-xs ml-4 font-mono">~/portfolio</span>
            </div>
            <div className="p-6 font-mono text-sm md:text-base">
              <div className="text-cyan-400">$</div>
              <div className="typing text-pink-400">
                {displayText}
                {displayText.length < fullText.length && <span className="animate-pulse">▌</span>}
              </div>
            </div>
          </div>

          {/* Profile Info */}
          <div className="space-y-4">
            <div>
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight">
                <span className="gradient-text">Kairam Akshay</span>
              </h1>
              <p className="text-xl md:text-2xl text-gray-300 mt-2">AI & ML Engineer | Full-Stack Developer</p>
            </div>

            <p className="text-gray-400 text-base md:text-lg leading-relaxed max-w-md">
              Building intelligent systems that solve real-world problems. Passionate about machine learning, cloud
              technologies, and creating exceptional digital experiences.
            </p>
          </div>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 pt-4">
            <button
              onClick={scrollToProjects}
              className="group glass rounded-lg px-8 py-3 font-medium flex items-center gap-2 hover-scale glass-hover"
            >
              View Projects
              <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
            </button>
            <button
              onClick={handleDownloadResume}
              className="group rounded-lg px-8 py-3 font-medium flex items-center gap-2 border-2 border-purple-500 hover:bg-purple-500/10 hover-scale transition-all"
            >
              <Download size={20} />
              Download Resume
            </button>
          </div>

          {/* Social Links */}
          <div className="flex gap-4 pt-4">
            <a
              href="https://linkedin.com/in/akshay-kairam"
              target="_blank"
              rel="noopener noreferrer"
              className="glass rounded-lg p-3 hover-scale glass-hover"
              title="LinkedIn"
            >
              <Linkedin size={20} />
            </a>
            <a
              href="https://github.com/KairamAkshay"
              target="_blank"
              rel="noopener noreferrer"
              className="glass rounded-lg p-3 hover-scale glass-hover"
              title="GitHub"
            >
              <Github size={20} />
            </a>
          </div>
        </div>

        {/* Right Side - Profile Card */}
        <div className="relative h-96 lg:h-[500px] flex items-center justify-center">
          {/* 3D Card Background */}
          <div
            className="absolute inset-0 rounded-2xl glass neon-glow"
            style={{
              transform: "perspective(1000px) rotateY(-15deg) rotateX(5deg)",
            }}
          />

          {/* Profile Image Container */}
          <div className="relative z-10 w-64 h-64 rounded-full overflow-hidden border-2 border-purple-500/30">
            <img src="/images/my-20photo.jpg" alt="Kairam Akshay" className="w-full h-full object-cover" />
            {/* Gradient Overlay */}
            <div className="absolute inset-0 bg-gradient-to-br from-purple-500/20 via-pink-500/10 to-cyan-500/20 rounded-full" />
          </div>

          {/* Floating Code Icons */}
          <div className="absolute top-10 right-10 text-3xl text-purple-400 opacity-60 animate-bounce">{"</>"}</div>
          <div className="absolute bottom-20 left-10 text-3xl text-pink-400 opacity-60 animate-pulse">{"{}"}</div>
          <div className="absolute top-1/3 right-0 text-3xl text-cyan-400 opacity-60">{"[]"}</div>
        </div>
      </div>
    </section>
  )
}
